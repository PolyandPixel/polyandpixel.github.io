greeting = 'hello world!'
print(greeting)