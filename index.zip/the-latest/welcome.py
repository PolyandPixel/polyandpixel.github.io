line01 = '*******************'
line02 = '*                 *'
line03 = '*     WELCOME!    *'

print('')
print(line01)
print(line02)
print(line03)
print(line02)
print(line01)
