nums = [2, 434, 5, 646, 4, 2356, 5]

mynums = nums.copy()
numsCopy = list(nums)
nums_variable = nums[:]

print(nums)
print(mynums)
print(numsCopy)
print(nums_variable)

print(sorted(nums, reverse=False))
